# Calculadora interestelar - Projeto

A Pen created on CodePen.io. Original URL: [https://codepen.io/Lucas-aos/pen/Vwgzzmq](https://codepen.io/Lucas-aos/pen/Vwgzzmq).

Esse é um projeto da aula I da imersão dev que envolve a funcionalidade simples de preenchimento do nome do usuário,  conversão de quilômetros para anos-luz e descobrir o tempo necessário para viajar do sol até 2 estrelas parametrizadas.